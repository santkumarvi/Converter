﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvertNumberIntoBritishWords
{
    class Program
    {
        static void Main()
        {
            string input;
            int number;
            bool isValid;
            bool isBritish = false; 
            Console.WriteLine("\nEnter '0' to quit the program at any time\n");
            while (true)
            {
                Console.Write("\nUse British numbering y/n : ");
                input = Console.ReadLine();
                if (!(input.ToLower() == "y" || input.ToLower() == "n"))
                    Console.WriteLine("\n  Must be 'y' or 'n', please try again\n");
                else
                {
                    if (input.ToLower() == "y") isBritish = true; 
                    Console.WriteLine("\n");
                    break;
                }
            }
            do
            {
                Console.Write("Enter integer : ");
                input = Console.ReadLine();
                isValid = int.TryParse(input, out number);
                if (!isValid)
                    Console.WriteLine("\n  Not an integer, please try again\n");
                else
                    Console.WriteLine("\n  {0}\n", ConvertNumberToBritishWords.NumberToBritishWords(number, isBritish));
            }
            while (!(isValid && number == 0));
            Console.WriteLine("\nProgram ended");
        }
       
    }
}
